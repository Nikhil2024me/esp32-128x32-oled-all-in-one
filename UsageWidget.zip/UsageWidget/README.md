# AI Usage Widget

Home-screen widget (Jetpack Glance) showing usage bars and reset countdowns for AI tools.

## Build
1. Unzip, open the folder in Android Studio (Ladybug or newer). It generates the Gradle wrapper and syncs.
2. Run on a device (minSdk 26), or Build > Build APK(s).
3. Long-press home screen > Widgets > "AI Usage" (4x2, resizable).

## Using it
- Open the app, tap a tool to edit used/limit/unit, or + to add one.
- Claude.ai and Antigravity expose no usage API: copy the figure from their usage/quota page into the app. Default unit is %.
- "Reset every (h)" auto-zeroes usage and runs the countdown (e.g. 5 for Claude's rolling window, 168 for weekly).
- Source `anthropic` / `openai` pulls month-to-date API tokens using an org Admin key. This covers API billing only, not chat plans.
- Widget refreshes every 15 min via WorkManager; "Sync" on the widget forces it.

## Notes
- API keys sit in app-private SharedPreferences (unencrypted). Use read-only admin keys.
- API endpoints are written from docs, untested; failures leave the last value in place.
