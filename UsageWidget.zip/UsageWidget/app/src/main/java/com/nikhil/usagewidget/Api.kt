package com.nikhil.usagewidget

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.ZoneOffset

/**
 * Optional API sync. Both endpoints need an organization ADMIN key and report
 * API (pay-per-token) usage only - not consumer chat plans like claude.ai.
 * Returns month-to-date tokens, or null on any failure (widget keeps old value).
 */
object Api {
    fun fetch(tool: Tool): Double? = try {
        when (tool.source) {
            "anthropic" -> anthropic(tool.apiKey)
            "openai" -> openai(tool.apiKey)
            else -> null
        }
    } catch (e: Exception) {
        null
    }

    private fun monthStart() =
        LocalDate.now(ZoneOffset.UTC).withDayOfMonth(1).atStartOfDay().toInstant(ZoneOffset.UTC)

    private fun get(url: String, headers: Map<String, String>): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 15_000
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) error("HTTP $code")
        return JSONObject(body)
    }

    private fun anthropic(key: String): Double {
        val url = "https://api.anthropic.com/v1/organizations/usage_report/messages" +
            "?starting_at=${monthStart()}&bucket_width=1d&limit=31"
        val json = get(url, mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"))
        var total = 0.0
        val buckets = json.optJSONArray("data") ?: return 0.0
        for (i in 0 until buckets.length()) {
            val results = buckets.getJSONObject(i).optJSONArray("results") ?: continue
            for (j in 0 until results.length()) {
                val r = results.getJSONObject(j)
                total += r.optDouble("uncached_input_tokens", 0.0)
                total += r.optDouble("cache_read_input_tokens", 0.0)
                total += r.optDouble("output_tokens", 0.0)
                r.optJSONObject("cache_creation")?.let {
                    total += it.optDouble("ephemeral_5m_input_tokens", 0.0)
                    total += it.optDouble("ephemeral_1h_input_tokens", 0.0)
                }
            }
        }
        return total
    }

    private fun openai(key: String): Double {
        val start = monthStart().epochSecond
        val url = "https://api.openai.com/v1/organization/usage/completions" +
            "?start_time=$start&bucket_width=1d&limit=31"
        val json = get(url, mapOf("Authorization" to "Bearer $key"))
        var total = 0.0
        val buckets = json.optJSONArray("data") ?: return 0.0
        for (i in 0 until buckets.length()) {
            val results = buckets.getJSONObject(i).optJSONArray("results") ?: continue
            for (j in 0 until results.length()) {
                val r = results.getJSONObject(j)
                total += r.optDouble("input_tokens", 0.0) + r.optDouble("output_tokens", 0.0)
            }
        }
        return total
    }
}
