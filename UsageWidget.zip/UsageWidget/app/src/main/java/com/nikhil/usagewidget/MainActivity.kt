@file:OptIn(ExperimentalMaterial3Api::class)

package com.nikhil.usagewidget

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RefreshWorker.schedule(this)
        setContent {
            MaterialTheme {
                Surface { Screen() }
            }
        }
    }
}

@Composable
private fun Screen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tools by remember { mutableStateOf(Store.load(ctx).map { Store.roll(it) }) }
    var editing by remember { mutableStateOf<Tool?>(null) }

    fun persist(list: List<Tool>) {
        tools = list
        Store.save(ctx, list)
        scope.launch { UsageWidget().updateAll(ctx) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Usage") },
                actions = { TextButton(onClick = { RefreshWorker.runNow(ctx) }) { Text("Sync now") } },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { editing = Tool(name = "") }) { Text("+") }
        },
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(tools, key = { it.id }) { t ->
                Card(onClick = { editing = t }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(t.name, style = MaterialTheme.typography.titleMedium)
                            Text("${fmt(t.used)}/${fmt(t.limit)} ${t.unit}")
                        }
                        LinearProgressIndicator(progress = { t.fraction }, modifier = Modifier.fillMaxWidth())
                        val sub = buildList {
                            if (t.resetAt > 0) add(fmtRemaining(t.resetAt))
                            if (t.source != "manual") add("synced via ${t.source}")
                        }.joinToString(" • ")
                        if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    editing?.let { current ->
        EditDialog(
            initial = current,
            onDismiss = { editing = null },
            onSave = { n ->
                persist(if (tools.any { it.id == n.id }) tools.map { if (it.id == n.id) n else it } else tools + n)
                editing = null
            },
            onDelete = { persist(tools.filter { x -> x.id != current.id }); editing = null },
        )
    }
}

@Composable
private fun EditDialog(
    initial: Tool,
    onDismiss: () -> Unit,
    onSave: (Tool) -> Unit,
    onDelete: () -> Unit,
) {
    var name by remember { mutableStateOf(initial.name) }
    var used by remember { mutableStateOf(fmt(initial.used)) }
    var limit by remember { mutableStateOf(fmt(initial.limit)) }
    var unit by remember { mutableStateOf(initial.unit) }
    var period by remember { mutableStateOf(initial.periodHours.toString()) }
    var source by remember { mutableStateOf(initial.source) }
    var key by remember { mutableStateOf(initial.apiKey) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.name.isEmpty()) "Add tool" else "Edit ${initial.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(used, { used = it }, label = { Text("Used") },
                        singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(limit, { limit = it }, label = { Text("Limit") },
                        singleLine = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(unit, { unit = it }, label = { Text("Unit") },
                        singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(period, { period = it }, label = { Text("Reset every (h)") },
                        singleLine = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("manual", "anthropic", "openai").forEach { s ->
                        FilterChip(selected = source == s, onClick = { source = s }, label = { Text(s) })
                    }
                }
                if (source != "manual") {
                    OutlinedTextField(key, { key = it }, label = { Text("Admin API key") }, singleLine = true)
                    Text("Month-to-date tokens, API usage only. Set unit to tok.",
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val hours = period.toIntOrNull() ?: 0
                val resetAt = when {
                    hours <= 0 -> 0L
                    initial.resetAt > 0 && hours == initial.periodHours -> initial.resetAt
                    else -> System.currentTimeMillis() + hours * 3_600_000L
                }
                onSave(
                    initial.copy(
                        name = name.trim().ifEmpty { "Tool" },
                        used = used.toDoubleOrNull() ?: 0.0,
                        limit = limit.toDoubleOrNull() ?: 100.0,
                        unit = unit.trim(),
                        periodHours = hours,
                        resetAt = resetAt,
                        source = source,
                        apiKey = key.trim(),
                    )
                )
            }) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (initial.name.isNotEmpty()) TextButton(onClick = onDelete) { Text("Delete") }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        },
    )
}
