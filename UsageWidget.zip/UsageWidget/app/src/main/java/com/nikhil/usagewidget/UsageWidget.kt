package com.nikhil.usagewidget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.action.ActionParameters
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.LinearProgressIndicator
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.lazy.LazyColumn
import androidx.glance.appwidget.lazy.items
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider

class UsageWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val tools = Store.load(context).map { Store.roll(it) }
        provideContent {
            GlanceTheme { WidgetContent(tools) }
        }
    }
}

class UsageWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = UsageWidget()

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        RefreshWorker.schedule(context)
    }
}

class RefreshCallback : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        RefreshWorker.runNow(context)
    }
}

private fun barColor(f: Float) = when {
    f >= 0.9f -> ColorProvider(Color(0xFFE53935))
    f >= 0.7f -> ColorProvider(Color(0xFFFFA000))
    else -> ColorProvider(Color(0xFF43A047))
}

@Composable
private fun WidgetContent(tools: List<Tool>) {
    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(GlanceTheme.colors.widgetBackground)
            .cornerRadius(20.dp)
            .padding(12.dp)
            .clickable(actionStartActivity<MainActivity>()),
    ) {
        Row(modifier = GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "AI usage",
                modifier = GlanceModifier.defaultWeight(),
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = GlanceTheme.colors.onSurface,
                ),
            )
            Text(
                "Sync",
                modifier = GlanceModifier
                    .padding(4.dp)
                    .clickable(actionRunCallback<RefreshCallback>()),
                style = TextStyle(fontSize = 12.sp, color = GlanceTheme.colors.primary),
            )
        }
        Spacer(GlanceModifier.height(6.dp))
        LazyColumn {
            items(tools) { t -> ToolRow(t) }
        }
    }
}

@Composable
private fun ToolRow(t: Tool) {
    Column(modifier = GlanceModifier.fillMaxWidth().padding(bottom = 8.dp)) {
        Row(modifier = GlanceModifier.fillMaxWidth()) {
            Text(
                t.name,
                modifier = GlanceModifier.defaultWeight(),
                style = TextStyle(fontSize = 13.sp, color = GlanceTheme.colors.onSurface),
            )
            Text(
                "${fmt(t.used)}/${fmt(t.limit)} ${t.unit}",
                style = TextStyle(fontSize = 12.sp, color = GlanceTheme.colors.onSurfaceVariant),
            )
        }
        Spacer(GlanceModifier.height(3.dp))
        LinearProgressIndicator(
            progress = t.fraction,
            modifier = GlanceModifier.fillMaxWidth(),
            color = barColor(t.fraction),
            backgroundColor = GlanceTheme.colors.secondaryContainer,
        )
        if (t.resetAt > 0) {
            Text(
                fmtRemaining(t.resetAt),
                style = TextStyle(fontSize = 10.sp, color = GlanceTheme.colors.onSurfaceVariant),
            )
        }
    }
}
