package com.nikhil.usagewidget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Tool(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val used: Double = 0.0,
    val limit: Double = 100.0,
    val unit: String = "%",
    val resetAt: Long = 0L,        // epoch millis, 0 = no reset timer
    val periodHours: Int = 0,      // >0: auto-roll resetAt and zero `used` when it passes
    val source: String = "manual", // manual | anthropic | openai
    val apiKey: String = "",       // admin key, only for api sources
) {
    val fraction: Float
        get() = if (limit <= 0) 0f else (used / limit).toFloat().coerceIn(0f, 1f)

    fun toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("used", used); put("limit", limit)
        put("unit", unit); put("resetAt", resetAt); put("periodHours", periodHours)
        put("source", source); put("apiKey", apiKey)
    }

    companion object {
        fun fromJson(o: JSONObject) = Tool(
            id = o.optString("id", UUID.randomUUID().toString()),
            name = o.optString("name"),
            used = o.optDouble("used", 0.0),
            limit = o.optDouble("limit", 100.0),
            unit = o.optString("unit", "%"),
            resetAt = o.optLong("resetAt", 0L),
            periodHours = o.optInt("periodHours", 0),
            source = o.optString("source", "manual"),
            apiKey = o.optString("apiKey", ""),
        )
    }
}

object Store {
    private const val PREFS = "usage"
    private const val KEY = "tools"

    fun load(ctx: Context): List<Tool> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        if (raw == null) {
            return listOf(Tool(name = "Claude"), Tool(name = "Antigravity"))
        }
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { Tool.fromJson(arr.getJSONObject(it)) }
    }

    fun save(ctx: Context, tools: List<Tool>) {
        val arr = JSONArray().apply { tools.forEach { put(it.toJson()) } }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    /** Zero usage and advance the reset time if the reset moment has passed. */
    fun roll(t: Tool, now: Long = System.currentTimeMillis()): Tool {
        if (t.periodHours <= 0 || t.resetAt <= 0 || now < t.resetAt) return t
        val period = t.periodHours * 3_600_000L
        var next = t.resetAt
        while (next <= now) next += period
        return t.copy(used = 0.0, resetAt = next)
    }
}

fun fmt(d: Double): String =
    if (d % 1.0 == 0.0) d.toLong().toString() else "%.1f".format(d)

fun fmtRemaining(resetAt: Long, now: Long = System.currentTimeMillis()): String {
    val mins = (resetAt - now) / 60_000
    if (mins <= 0) return "resetting"
    val d = mins / 1440
    val h = (mins % 1440) / 60
    val m = mins % 60
    return when {
        d > 0 -> "resets in ${d}d ${h}h"
        h > 0 -> "resets in ${h}h ${m}m"
        else -> "resets in ${m}m"
    }
}
